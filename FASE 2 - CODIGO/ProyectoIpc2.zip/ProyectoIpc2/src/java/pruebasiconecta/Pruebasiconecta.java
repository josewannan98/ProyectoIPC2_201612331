/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasiconecta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author jose
 */
public class Pruebasiconecta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        Pruebasiconecta ps = new Pruebasiconecta();
//        System.out.println(ps.agregarUsuario("jose", 19, 54951895, "wannan"));
        //System.out.println(ps.agregarVehiculo("BMP-0999", "Mazda", 1, 3));
    }
    public boolean agregarVehiculo(String matricula, String Modelo, int idvehiculo, int idasociado) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO VEHICULO(matricula,modelo,id_tipovehiculo,id_asociado)"
                + "VALUES(?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, matricula);
            /* ? */preparedStatement.setString(2, Modelo);  
            /* ? */preparedStatement.setInt(3, idvehiculo);
            /* ? */preparedStatement.setInt(4, idasociado);
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    
}
    public boolean agregarUsuario(String name, int Edad, int Tele, String pass) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO CLIENTE(nombre,Edad,Telefono,Contrasena)"
                + "VALUES(?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, name);
            /* ? */preparedStatement.setInt(2, Edad);  
            /* ? */preparedStatement.setInt(3, Tele);
            /* ? */preparedStatement.setString(4, pass);
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    
}
}
         
