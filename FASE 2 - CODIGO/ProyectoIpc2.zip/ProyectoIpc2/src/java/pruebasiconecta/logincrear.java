/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasiconecta;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 *
 * @author jose
 */
public class logincrear {
    //INSERT INTO USUARIO(usuario,nombre_completo,correo,fecha_nacimiento,contraseña,tipo_usuario) VALUES('josewan98','Jose Orlando Wannan Escobar','jwannan13@gmail.com','1998-06-20','josewannan','administrador')
    //usuario
    
    public String recordarcontra(String nickname, String correo) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="Nope";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM USUARIO  WHERE nickname = ? AND correo = ? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nickname);
            /* ? */preparedStatement.setString(2, correo);
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= "[ Usuario= "+ rs.getString(1)+", Contraseña= "+rs.getString(7)+"]";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
    
    
    
    public boolean agregarUsuario(String name, String nombre, String correo, String fechanacimiento, String contraseña, String tipo_usuario, String nickname) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO USUARIO(usuariosa,nombre_completo,correo,fecha_nacimiento,contraseña,tipo_usuario,nickname)"
                + "VALUES(?,?,?,?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, name);
            /* ? */preparedStatement.setString(2, nombre);
            /* ? */preparedStatement.setString(3, correo);
            /* ? */preparedStatement.setString(4, fechanacimiento);
            /* ? */preparedStatement.setString(5, contraseña);
            /* ? */preparedStatement.setString(6, tipo_usuario);
            preparedStatement.setString(7, nickname);
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    
}
   
    public String ingresarUsuario(String name, String contraseña) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="Nope";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM USUARIO  WHERE usuariosa = ? AND contraseña = ? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, name);
            /* ? */preparedStatement.setString(2, contraseña);
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= ""+ rs.getString(1)+","+rs.getString(9)+","+rs.getString(8);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Nope";
    
}
   //estados
    public boolean insertarestado(String descripcion, int idusuario) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO PUBLICACION(descripcion,id_usuario)"
                + "VALUES(?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, descripcion);
            /* ? */preparedStatement.setInt(2, idusuario);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    
}
   
    public boolean insertarcomentario(String descripcion,int idpublicacion,int idusuario) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO COMENTARIO(decripcion,id_publicacion,id_usuario)"
                + "VALUES(?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, descripcion);
                   preparedStatement.setInt(2, idpublicacion);
            /* ? */preparedStatement.setInt(3, idusuario);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
           try{
                    Boolean usuarios = obtenerpublicacion(idpublicacion, idusuario);
                   return usuarios;
               }catch(Exception s){
                   
               }
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
    
}
    public Boolean obtenerpublicacion(int idpublicacion, int idusuario) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM PUBLICACION  WHERE id_publicacion =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idpublicacion);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(3);
          }
           System.out.println(usuario);
               
                try{
                    Boolean usuarios = notificarcomentario(usuario, idusuario);
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
    }
    public Boolean notificarcomentario(int id_usuario, int idusuariohace) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO NOTIFICACION(id_usuario,id_usuariosolicitante,mensajes)"
                + "VALUES(?,?,'comento tu estado')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, id_usuario);
            /* ? */preparedStatement.setInt(2, idusuariohace);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }
    
    public Boolean denunciarpublicacion(int publicacion) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "UPDATE PUBLICACION SET denunciado='SI' WHERE id_publicacion = ?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, publicacion);
          
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    } 
    
    public Boolean denunciarcomentario(int comentario) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "UPDATE COMENTARIO SET denunciado='SI' WHERE id_comentario = ?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, comentario);
          
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    } 
    
    public Boolean denunciarmensaje(int mensaje) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "UPDATE MENSAJE SET denunciado='SI' WHERE id_mensaje = ?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, mensaje);
          
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    } 
    
    //habulidades conocimientos
    public boolean insertarconocimiento(int idusuario,int idconocimiento) throws SQLException {
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO DETALLE_CONOCIMIENTO(karma,id_usuario,id_conocimiento)"
                + "VALUES(0,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
           
                   preparedStatement.setInt(1, idusuario);
            /* ? */preparedStatement.setInt(2, idconocimiento);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
          
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
       
}
   
    public Boolean habilidad(int idusuario, int conocimiento) throws SQLException{
        Boolean habilidad= false;
        int habilidads=0;
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM detale_habilidadconocimiento WHERE id_conocimiento=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, conocimiento);
                   
          
            // execute insert SQL stetement
             preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                habilidads = rs.getInt(1);
          }
           
               
                try{
                    
                   Boolean bols = agregarhabilidad(idusuario,habilidads);
                   return bols;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
          
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
        
    }
    
    public Boolean agregarhabilidad(int idusuario,int habilidad) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO detalle_habilidad(karma,id_usuario,id_habilidad)"
                + "VALUES(?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, 0);
                   preparedStatement.setInt(2, idusuario);
            /* ? */preparedStatement.setInt(3, habilidad);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
          
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }
    //mensaje
    public Boolean enviarmensajecontacto(String mensaje, int idusuario, int idusuario1) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO MENSAJE(mensaje,id_usuario,id_remitente,ubicacion)"
                + "VALUES(?,?,?,'Estado de contacto')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, mensaje);
            /* ? */preparedStatement.setInt(2, idusuario1);
            /* ? */preparedStatement.setInt(3, idusuario);
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                Boolean respuesta = notificacionmensaje(idusuario1, idusuario);
                return respuesta;
            }catch(Exception as){
                
            }
         
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
    }
    public Boolean notificacionmensaje(int usuario1, int usuario2) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO NOTIFICACION(id_usuario,id_usuariosolicitante,mensajes)"
                + "VALUES(?,?,'te envio un mensaje')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, usuario1);
            /* ? */preparedStatement.setInt(2, usuario2);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }
   //asd
    public Boolean seguirUsuario(int usuario1, int usuario2) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO CONTACTO(id_usuario,id_amigo)"
                + "VALUES(?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, usuario1);
            /* ? */preparedStatement.setInt(2, usuario2);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
               Boolean respuesta=notificacion(usuario2,usuario1);
               return respuesta;
            }catch(Exception s){
                
            }
            
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
    }
    public Boolean notificacion(int usuario1, int usuario2) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO NOTIFICACION(id_usuario,id_amigo,mensaje)"
                + "VALUES(?,?,'te sigue')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, usuario2);
            /* ? */preparedStatement.setInt(2, usuario1);
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }
    //asociacion
    public int Obtenerkarma(int idusuario) throws SQLException, SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM USUARIO WHERE id_usuario = ? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
            
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(3);
          }
           
               
                try{
                    int usuario1 = obtenerhabilidad(idusuario);
                    int usuarios = usuario/usuario1;
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return usuario;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return usuario;
    }
    public int obtenerhabilidad(int idusuario) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM DETALLE_CONOCIMIENTO  WHERE id_usuario = ? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
            
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario+= rs.getInt(1);
          }
           
               
                try{
                   
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return usuario;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return usuario;
    }
    
    public String obtenernotificacion (int idusuario) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM NOTIFICACION WHERE id_usuario = ? ORDER BY id_usuario DESC LIMIT 4";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
            
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
            
          while(rs.next()){
                usuario+= "["+obteneruser(rs.getInt(3))+" @ "+rs.getString(4)+"],";
          }
           
               
                try{
                   
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Error(501)";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
    
    public String obtenernotificacionasociado(int idusuarioquehace) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM detalle_asociacion WHERE id_usuario = ? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuarioquehace);
            
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
            int asociacion=0;
          while(rs.next()){
                asociacion= rs.getInt(2);
          }
           
               
                try{
                   String usuarios= obtenernotificacionesaso(asociacion);
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Error(501)";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
    public String obtenernotificacionesaso(int idusuarioquehace) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM NOTIFICACION_ASOCIACION WHERE id_asociacion = ? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuarioquehace);
            
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
            int asociacion=0;
          while(rs.next()){
                usuario+= "["+obteneruser(rs.getInt(4))+" @ "
                        +rs.getString(3) +" en la asociacion: @"+obtenerasociacion(rs.getInt(2))+"],";
          }
           
               
                try{
                   
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Error(501)";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
    public String obtenerasociacion(int idasociacion) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="Nope";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM ASOCIACION  WHERE id_asociacion =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idasociacion);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= ""+ rs.getString(2);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
    public String obteneruser(int usuarios) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="Nope";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM USUARIO  WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, usuarios);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= ""+ rs.getString(9);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
    // crear tarea
    public Boolean creartareas(String nombre, String descripcion, int idusuario, String fechainicio, double precio,String duracion) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO TAREA(nombre,descripcion,id_usuario,fecha_inicio,valor,duracion)"
                + "VALUES(?,?,?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nombre);
            /* ? */preparedStatement.setString(2, descripcion);
            /* ? */preparedStatement.setInt(3, idusuario);
            /* ? */preparedStatement.setString(4, fechainicio);
            /* ? */preparedStatement.setDouble(5, precio);
                   preparedStatement.setString(6, duracion);
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }
   
    //---proyectos y tareas---
    public Boolean crearproyecto(String nombre, String fechainicio, String fechafin, double presupuesto, String modo, int idusuario, int cupos) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO PROYECTO(nombre,fecha_inicio,fecha_fin,Estado,salario,modopago,id_usuario,cuposdisponibles)"
                + "VALUES(?,?,?,?,?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nombre);
            /* ? */preparedStatement.setString(2, fechainicio);
            /* ? */preparedStatement.setString(3, fechafin);
            /* ? */preparedStatement.setString(4, "Sin Publicar");
            /* ? */preparedStatement.setDouble(5, presupuesto);
                   preparedStatement.setString(6,modo);
            /* ? */preparedStatement.setInt(7, idusuario);
            preparedStatement.setInt(8, cupos);
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    
    }
    
    public Boolean creartarea(String nombre, String descripcion, int idusuario, String fechainicio, double precio,String duracion, int idproyecto, String fase) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO TAREA(nombre,descripcion,id_usuario,fecha_inicio,valor,duracion)"
                + "VALUES(?,?,?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nombre);
            /* ? */preparedStatement.setString(2, descripcion);
            /* ? */preparedStatement.setInt(3, idusuario);
            /* ? */preparedStatement.setString(4, fechainicio);
            /* ? */preparedStatement.setDouble(5, precio);
                   preparedStatement.setString(6, duracion);
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
             try{
                    Boolean usuarios = agregartareaproyecto(nombre,idusuario,idproyecto, fase);
                   return usuarios;
               }catch(Exception s){
                   
               }
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
    }

    public Boolean agregartareaproyecto(String nombre, int idusuario, int idproyecto, String fase) throws SQLException{
         Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM TAREA  WHERE id_usuario =? AND nombre=? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
            /* ? */preparedStatement.setString(2, nombre);
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                    Boolean usuarios = agregartareitaproyecto(usuario,idproyecto, fase);
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
    }
    public Boolean agregartareitaproyecto(int idtarea, int idproyecto, String fase) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO DETALLE_TAREA(Fase_proyecto,id_tarea,id_proyecto)"
                + "VALUES(?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, fase);
            /* ? */preparedStatement.setInt(2, idtarea);
            /* ? */preparedStatement.setInt(3, idproyecto);
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            
                    
                   return true;
              
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }

    }
    
    public Boolean agregarconocimientoatarea(int idtarea, int idconocimiento) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO conocimiento_necesariotarea(id_tarea,id_conocimiento)"
                + "VALUES(?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idtarea);
            /* ? */preparedStatement.setInt(2, idconocimiento);
         
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            
                    
                   return true;
              
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    }

public int obtenercontactos(int idusuario) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM CONTACTO WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public int obtenermensajescantidad(int idusuario) throws SQLException{
     Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM MENSAJE WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public int obtenerproyectoscantidad(int idusuario) throws SQLException{
     Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM COLABORADORPROYECTO  WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public int obtenertareascantidad(int idusuario) throws SQLException{
     Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM tarea_asignada  WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                    int usuarios = obtenerenproyecto(idusuario);
                    int prro = usuario + usuarios;
                   return prro;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}

public int obtenerenproyecto(int idusuario) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM COLABORADORPROYECTO  WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                    int usuarios = obtenertareacantidadproyectos(usuario);
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public int obtenertareacantidadproyectos(int idcolaboradorproyecto) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM tarea_asignadaproyecto  WHERE id_colaboradorproyecto =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idcolaboradorproyecto);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}


public int obtenerproyectosss() throws SQLException{
     Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM PROYECTO";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public int obtenerasociacioness() throws SQLException{
     Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM ASOCIACION";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public int obtenertareass() throws SQLException{
     Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT COUNT(*) FROM TAREA";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return 0;
}
public String obtenerpublicaciones() throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM PUBLICACION ORDER BY id_publicacion DESC LIMIT 10";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+" @ "+rs.getString(2)+" @ "+obteneruser(rs.getInt(3))+"],";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}
public String obtenercomentario(int idpublicacion) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM COMENTARIO where id_publicacion=? ORDER BY id_comentario DESC LIMIT 4";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            preparedStatement.setInt(1, idpublicacion);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +="["+rs.getInt(1)+" @ "+rs.getString(2)+" @ "+obteneruser(rs.getInt(4))+"],";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}
public String obtenername(int idpublicacion) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM CONTACTO where id_usuario=? LIMIT 15";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            preparedStatement.setInt(1, idpublicacion);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+"|"+obteneruser(rs.getInt(3))+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}
public String obtenerperfil(int idpublicacion) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM USUARIO where id_usuario=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            preparedStatement.setInt(1, idpublicacion);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +="["+rs.getString(2)+" | "+rs.getString(4)+" | "+rs.getString(5)+" | "+rs.getString(6)+" | "+rs.getString(7)+" | "+rs.getString(9)+"]";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}

public Boolean actualizarusuario(String name, String nombre, String correo, String fechanacimiento, String contraseña, String nickname, int idusuarios) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "UPDATE USUARIO SET usuariosa=?,nombre_completo=?,correo=?,fecha_nacimiento=?,contraseña=?,nickname=? WHERE id_usuario=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, name);
            /* ? */preparedStatement.setString(2, nombre);
            /* ? */preparedStatement.setString(3, correo);
            /* ? */preparedStatement.setString(4, fechanacimiento);
            /* ? */preparedStatement.setString(5, contraseña);
            /* ? */preparedStatement.setString(6, nickname);
            preparedStatement.setInt(7, idusuarios);
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    
}


public String buscarusuario(String nickname) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM USUARIO where nickname=? LIMIT 2";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            preparedStatement.setString(1, nickname);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(4)+" | "+rs.getString(5)+" | "+rs.getString(9)+"],";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}

public String buscarasociacion() throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM ASOCIACION LIMIT 4";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
           
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(4)+" | "+rs.getString(5)+" | "+rs.getString(9)+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}
public String buscarasociacions() throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM ASOCIACION LIMIT 4";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
           
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3)+" | "+obteneruser(rs.getInt(5))+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}

public Boolean unirseaasociacion(int idasociacion, int idusuarios) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO detalle_asociacion(id_asociacion,id_usuario,papel)"
                + "VALUES(?,?,'usuario')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idasociacion);
            /* ? */preparedStatement.setInt(2, idusuarios);
            
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                Boolean respuesta = notificarasociacion(idasociacion,idusuarios);
                return respuesta;
            }catch(Exception em){
                
            }
            
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    return false;
}
public Boolean notificarasociacion(int idasociacion, int idusuario) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO notificacion_asociacion(id_asociacion,id_usuariohace,mensajes)"
                + "VALUES(?,?,'se ha unido')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idasociacion);
            /* ? */preparedStatement.setInt(2, idusuario);
            
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
}

public String buscarproyectos() throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM PROYECTO Order By id_proyecto DESC LIMIT 4";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
           
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3)+" | "+rs.getString(4)+" | "+rs.getString(5)+" | "+rs.getString(6)+" | "+rs.getString(7)+" | "+obteneruser(rs.getInt(8))+" | "+rs.getString(9)+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}

public String buscartareas() throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT *FROM TAREA Order By id_tarea DESC LIMIT 4";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
           
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario +=""+rs.getInt(1)+" | "+rs.getString(2)+" | "+obteneruser(rs.getInt(4))+" | "+rs.getString(5)+" | "+rs.getString(6)+" | "+rs.getString(7)+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "Nope";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
     return "Nope";
}

public Boolean unirseproyecto(int idasociacion, int idusuarios) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO AVISO(id_proyecto,id_usuario,mensajed)"
                + "VALUES(?,?,'solicita unirse')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idasociacion);
            /* ? */preparedStatement.setInt(2, idusuarios);
            
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                Boolean respuesta = notificarasociacion(idasociacion,idusuarios);
                return respuesta;
            }catch(Exception em){
                
            }
            
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    return false;
}
public Boolean dejardeseguir(int idusuario, int idamigo) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "DELETE FROM CONTACTO WHERE id_usuario=? AND id_amigo=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
            /* ? */preparedStatement.setInt(2, idamigo);
            
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                
                return true;
            }catch(Exception em){
                
            }
            
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
    return false;
}
public String obtenerhabilidades(int idusuario) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM detalle_habilidad  WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario+= ""+rs.getInt(1)+"|"+"habilidad: "+ obhabilidad(rs.getInt(4))+". karma: "+rs.getString(2)+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    
}
  public String obhabilidad(int habilidad) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="Nope";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM HABILIDAD  WHERE id_habilidad =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, habilidad);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= ""+ rs.getString(2);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
  
  public String obtenerconocimiento(int idusuario) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM detalle_conocimiento  WHERE id_usuario =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario+= ""+rs.getInt(1)+"|"+"habilidad: "+ obconocimiento(rs.getInt(4))+". karma: "+rs.getString(2)+",";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    
}
  public String obconocimiento(int habilidad) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM CONOCIMIENTO  WHERE id_conocimiento =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, habilidad);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= ""+ rs.getString(2);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
    }
   public Boolean crearasociacion(String nombre, String descripcion, String logo, int idusuario) throws SQLException{
       Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO ASOCIACION(nombre,resumen,logo,id_usuarioadministrador)"
                + "VALUES(?,?,?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
           
                   preparedStatement.setString(1, nombre);
                   preparedStatement.setString(2, descripcion);
                   preparedStatement.setString(3, logo);
                   preparedStatement.setInt(4, idusuario);
     
          
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                Boolean user = obteneridaso(idusuario, nombre);
                return user;
            }catch(Exception sd){
                
            }
          
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
   }
   public Boolean obteneridaso(int idusuario, String nombre) throws SQLException{
       Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM ASOCIACION  WHERE id_usuarioadministrador =? AND nombre=? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
            preparedStatement.setString(2, nombre);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario=  rs.getInt(1);
          }
           
               
                try{
                    Boolean usuarios = notificarasociacioncreacion(usuario, idusuario);
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;
   }
   public Boolean notificarasociacioncreacion(int idasociacion, int idusuario) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO notificacion_asociacion(id_asociacion,id_usuariohace,mensajes)"
                + "VALUES(?,?,'(administrador)se ha unido')";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idasociacion);
            /* ? */preparedStatement.setInt(2, idusuario);
            
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            dbConnection.close();
            return true;
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
}

   public String buscartareas(String nombre) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM TAREA  WHERE nombre =? ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nombre);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= ""+rs.getInt(1)+","+ rs.getString(2);
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
   }
   public Boolean publicarproyecto(int idusuario, String nombre) throws SQLException{
      Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM PROYECTO  WHERE nombre =? AND id_usuario=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nombre);
            preparedStatement.setInt(2, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                    Boolean usuarios = crearproyectos(usuario);
                   return usuarios;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false; 
   }
   public Boolean crearproyectos(int idpublicacion) throws SQLException{
        Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "UPDATE PROYECTO SET Estado='Disponible' WHERE id_publicacion=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idpublicacion);
            
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                
                return true;
            }catch(Exception em){
                
            }
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false; 
   }
   public int obtenerproyects(int idusuario, String nombre) throws SQLException{
    Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM PROYECTO  WHERE nombre =? AND id_usuario=?";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setString(1, nombre);
            preparedStatement.setInt(2, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= rs.getInt(1);
          }
           
               
                try{
                   
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return 0;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return 0; 
   }
   
   public Boolean agregartareassd(int tarea, String nombre, int idusuario) throws SQLException{
      Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        int usuario=0;
        try{
       
        //SQL -- 
        String insertTableSQL = "INSERT INTO detalle_tarea(id_tarea, id_proyecto)"
                + "VALUES(?,?)";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, tarea);
            preparedStatement.setInt(2,obtenerproyects(idusuario,nombre));
            
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            preparedStatement.executeUpdate();
            
            preparedStatement.executeUpdate();
            dbConnection.close();
            try{
                
                return true;
            }catch(Exception em){
                
            }
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return false;

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return false;  
   }
   public String buscarsinpublicar(int idusuario) throws SQLException{
       Connection dbConnection = null;
         PreparedStatement preparedStatement = null;
        //ES PARA DECLARAR SENTENCIAS SQL
        String usuario="";
        try{
       
        //SQL -- 
        String insertTableSQL = "SELECT DISTINCT *FROM PROYECTO  WHERE id_usuario =? AND Estado = 'Sin Publicar' ";
            dbConnection = new Conexion().getconexion();
            preparedStatement = dbConnection.prepareStatement(insertTableSQL);
            /* ? */preparedStatement.setInt(1, idusuario);
         
          
            
            // execute insert SQL stetement
            preparedStatement.executeUpdate();
            
            ResultSet rs;
            rs = preparedStatement.executeQuery();
          while(rs.next()){
                usuario= "["+rs.getInt(2)+"|"+ rs.getString(3)+"|"+rs.getString(4)+"|"+rs.getString(5)+"|"+rs.getString(6)+"],";
          }
           
               
                try{
                   return usuario;
               }catch(Exception s){
                   
               }
            
            
            rs.close();
    }catch (SQLException e) {

            System.out.println(e.getMessage());
            return "algo anda mal";

                 }finally {
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return "Error(502)";
   }
}

