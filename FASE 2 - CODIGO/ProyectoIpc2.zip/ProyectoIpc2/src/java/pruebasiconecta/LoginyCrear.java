/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebasiconecta;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author jose
 */
@WebService(serviceName = "LoginyCrear")
public class LoginyCrear {
logincrear conect;
    /**
     * Web service operation
     */
    @WebMethod(operationName = "crearUsuario")
    public Boolean crearUsuario(@WebParam(name = "nickname") String nickname,@WebParam(name = "usuario") String usuario, @WebParam(name = "nombre_completo") String nombre_completo, @WebParam(name = "correo") String correo, @WebParam(name = "fecha_nacimiento") String fecha_nacimiento, @WebParam(name = "contrase\u00f1a") String contraseña) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        Boolean respuesta = conect.agregarUsuario(usuario, nombre_completo, correo, fecha_nacimiento, contraseña, "usuario", nickname);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }


    /**
     * Web service operation
     */
    @WebMethod(operationName = "ingresarusuario")
    public String ingresarusuario(@WebParam(name = "usuariosa") String usuario, @WebParam(name = "contrase\u00f1a") String contraseña) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        String respuesta = conect.ingresarUsuario(usuario, contraseña);
        return respuesta;
        }catch (Exception e){
            
        }
        return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "agregarestado")
    public Boolean agregarestado(@WebParam(name = "descripcion") String descripcion, @WebParam(name = "id_usuario") int id_usuario) {
        //TODO write your implementation code here:
         try{
        conect = new logincrear();
        
        Boolean respuesta = conect.insertarestado(descripcion, id_usuario);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "insertarcomentario")
    public Boolean insertarcomentario(@WebParam(name = "comentario") String comentario, @WebParam(name = "publicacion") int publicacion, @WebParam(name = "usuario") int usuario) {
        //TODO write your implementation code here:
       try{
        conect = new logincrear();
        
        Boolean respuesta = conect.insertarcomentario(comentario,publicacion,usuario);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "agregarconocimiento")
    public Boolean agregarconocimiento(@WebParam(name = "idusuario") int idusuario, @WebParam(name = "idconocimiento") int idconocimiento) {
        //TODO write your implementation code here:
      try{
        conect = new logincrear();
        
        Boolean respuesta = conect.insertarconocimiento(idusuario, idconocimiento);
        if(respuesta==true){
            Boolean respuesta1= conect.habilidad(idusuario, idconocimiento);
            return respuesta1;
        }else{
            return false;
        }
        
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "enviarmensaje")
    public Boolean enviarmensaje(@WebParam(name = "mensaje") String mensaje, @WebParam(name = "id_usuario") int id_usuario, @WebParam(name = "id_usuario1") int id_usuario1) {
        //TODO write your implementation code here:
         try{
        conect = new logincrear();
        
        Boolean respuesta = conect.enviarmensajecontacto(mensaje, id_usuario, id_usuario1);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "seguirUsuario")
    public Boolean seguirUsuario(@WebParam(name = "id_usuario") int id_usuario, @WebParam(name = "id_amigo") int id_amigo) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        Boolean respuesta = conect.seguirUsuario(id_usuario, id_amigo);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "denunciarpublicacion")
    public Boolean denunciarpublicacion(@WebParam(name = "publicacion") int publicacion) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        Boolean respuesta = conect.denunciarpublicacion(publicacion);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "denunciarcomentario")
    public Boolean denunciarcomentario(@WebParam(name = "comentario") int comentario) {
        //TODO write your implementation code here:
       try{
        conect = new logincrear();
        
        Boolean respuesta = conect.denunciarcomentario(comentario);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "denunciarmensaje")
    public Boolean denunciarmensaje(@WebParam(name = "mensaje") int mensaje) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        Boolean respuesta = conect.denunciarmensaje(mensaje);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerkarma")
    public int obtenerkarma(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
        conect = new logincrear();
        
        int respuesta = conect.Obtenerkarma(idusuario);
        return respuesta;
        }catch (Exception e){
            
        }
        return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerNotificaciones")
    public String obtenerNotificaciones(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        String respuesta = conect.obtenernotificacion(idusuario);
        return respuesta;
        }catch (Exception e){
            
        }
        return "ERROR (409)";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenernotificacionasosiacion")
    public String obtenernotificacionasosiacion(@WebParam(name = "id_usuario") int id_usuario) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        String respuesta = conect.obtenernotificacionasociado(id_usuario);
        return respuesta;
        }catch (Exception e){
            
        }
        return "ERROR (409)";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "crearProyecto")
    public Boolean crearProyecto(@WebParam(name = "nombre") String nombre, @WebParam(name = "fechainicio") String fechainicio, @WebParam(name = "fechafin") String fechafin, @WebParam(name = "presupuesto") double presupuesto,@WebParam(name = "modopago") String modo, @WebParam(name = "idusuario") int idusuario, @WebParam(name = "cupo") int cupo) {
        //TODO write your implementation code here:
       try{
        conect = new logincrear();
        
        Boolean respuesta = conect.crearproyecto(nombre, fechainicio, fechafin, presupuesto, modo, idusuario, cupo);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "agregartarea")
    public Boolean agregartarea(@WebParam(name = "nombre") String nombre, @WebParam(name = "descripcion") String descripcion, @WebParam(name = "idusuario") int idusuario, @WebParam(name = "fechainicio") String fechainicio, @WebParam(name = "precio") double precio, @WebParam(name = "duracion") String duracion) {
        //TODO write your implementation code here:
        try{
        conect = new logincrear();
        
        Boolean respuesta = conect.creartareas(nombre, descripcion, idusuario, fechainicio, precio, duracion);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "agregarTareaConocimiento")
    public Boolean agregarTareaConocimiento(@WebParam(name = "idtarea") int idtarea, @WebParam(name = "idconocimiento") int idconocimiento) {
        //TODO write your implementation code here:
       try{
        conect = new logincrear();
        
        Boolean respuesta = conect.agregarconocimientoatarea(idtarea, idconocimiento);
        return respuesta;
        }catch (Exception e){
            
        }
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "recordarcontra")
    public String recordarcontra(@WebParam(name = "nickname") String nickname, @WebParam(name = "correo") String correo) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.recordarcontra(nickname, correo);
           return respuesta;
       }catch(Exception e){
           
       }
       return "Error(502)";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenercontactoscantidad")
    public int obtenercontactoscantidad(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
         try{
           conect= new logincrear();
           int respuesta = conect.obtenercontactos(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenermensajecantidad")
    public int obtenermensajecantidad(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           int respuesta = conect.obtenermensajescantidad(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerproyectoscantidad")
    public int obtenerproyectoscantidad(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           int respuesta = conect.obtenerproyectoscantidad(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenertareascantidad")
    public int obtenertareascantidad(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           int respuesta = conect.obtenertareascantidad(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerasociacionss")
    public int obtenerasociacionss() {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           int respuesta = conect.obtenerasociacioness();
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenertareasss")
    public int obtenertareasss() {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           int respuesta = conect.obtenertareass();
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerprojectss")
    public int obtenerprojectss() {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           int respuesta = conect.obtenerproyectosss();
           return respuesta;
       }catch(Exception e){
           
       }
         return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "insertarestado")
    public Boolean insertarestado(@WebParam(name = "descripcion") String descripcion, @WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           Boolean respuesta = conect.insertarestado(descripcion, idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerpublicacion")
    public String obtenerpublicacion() {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.obtenerpublicaciones();
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenercomentario")
    public String obtenercomentario(@WebParam(name = "idpublicacion") int idpublicacion) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           String respuesta = conect.obtenercomentario(idpublicacion);
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "actualizarusuario")
    public Boolean actualizarusuario(@WebParam(name = "usuarios") String usuarios, @WebParam(name = "nombre") String nombre, @WebParam(name = "correo") String correo, @WebParam(name = "fecha_nacimiento") String fecha_nacimiento, @WebParam(name = "contrase\u00f1a") String contraseña, @WebParam(name = "nickname") String nickname, @WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           Boolean respuesta = conect.actualizarusuario(usuarios, nombre, correo, fecha_nacimiento, contraseña, nickname, idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerprfils")
    public String obtenerprfils(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           String respuesta = conect.obtenerperfil(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenercontactsname")
    public String obtenercontactsname(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
      try{
           conect= new logincrear();
           String respuesta = conect.obtenername(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "buscarusuario")
    public String buscarusuario(@WebParam(name = "nickname") String nickname) {
        //TODO write your implementation code here:
         try{
           conect= new logincrear();
           String respuesta = conect.buscarusuario(nickname);
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "unirseasociacion")
    public Boolean unirseasociacion(@WebParam(name = "idasociacion") int idasociacion, @WebParam(name = "idusuarios") int idusuarios) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           Boolean respuesta = conect.unirseaasociacion(idasociacion, idusuarios);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "asociacion")
    public String asociacion() {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.buscarasociacions();
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "proyectos")
    public String proyectos() {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           String respuesta = conect.buscarproyectos();
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "tareas")
    public String tareas() {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.buscartareas();
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "unirse")
    public Boolean unirse(@WebParam(name = "idproyecto") int idproyecto, @WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           Boolean respuesta = conect.unirseproyecto(idusuario, idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "eliminaruser")
    public Boolean eliminaruser(@WebParam(name = "idusuario") int idusuario, @WebParam(name = "idamigo") int idamigo) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           Boolean respuesta = conect.dejardeseguir(idusuario, idamigo);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerhabilidad")
    public String obtenerhabilidad(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.obtenerhabilidades(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "obtenerconocimiento")
    public String obtenerconocimiento(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           String respuesta = conect.obtenerconocimiento(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "agregarasociacion")
    public Boolean agregarasociacion(@WebParam(name = "nombre") String nombre, @WebParam(name = "descripcion") String descripcion, @WebParam(name = "logo") String logo, @WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
         try{
           conect= new logincrear();
           Boolean respuesta = conect.crearasociacion(nombre, descripcion, logo, idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sproyecto")
    public Boolean sproyecto(@WebParam(name = "nombre") String nombre, @WebParam(name = "fechainicio") String fechainicio, @WebParam(name = "fechafin") String fechafin, @WebParam(name = "salario") double salario, @WebParam(name = "mododepago") String mododepago, @WebParam(name = "idusuario") int idusuario, @WebParam(name = "cuposdisponibles") int cuposdisponibles) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           Boolean respuesta = conect.crearproyecto(nombre, fechainicio, fechafin, salario, mododepago, idusuario, cuposdisponibles);
           return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "agregarTareass")
    public Boolean agregarTareass(@WebParam(name = "tarea") int tarea, @WebParam(name = "nombre") String nombre, @WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           Boolean respuesta = conect.agregartareassd(tarea, nombre, idusuario);
                   return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "crearfinalproyecto")
    public Boolean crearfinalproyecto(@WebParam(name = "nombre") String nombre, @WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
        try{
           conect= new logincrear();
           Boolean respuesta = conect.publicarproyecto(idusuario, nombre);
                   return respuesta;
       }catch(Exception e){
           
       }
         return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "buscartarea")
    public String buscartarea(@WebParam(name = "nombre") String nombre) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.buscartareas(nombre);
                   return respuesta;
       }catch(Exception e){
           
       }
         return "Nope";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "buscarsinpublicar")
    public String buscarsinpublicar(@WebParam(name = "idusuario") int idusuario) {
        //TODO write your implementation code here:
       try{
           conect= new logincrear();
           String respuesta = conect.buscarsinpublicar(idusuario);
           return respuesta;
       }catch(Exception e){
           
       }
       return "Nope";
    }
    
    }

   
    
    

