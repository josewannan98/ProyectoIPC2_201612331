﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class crearcuenta1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear crearcuenta = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            String ms = TextBox5.Text;
            String fecha = String.Format("{0:yy-MM-dd}", ms);
            Console.WriteLine(fecha);
            crearcuenta.crearUsuario(TextBox1.Text,TextBox2.Text,TextBox3.Text,TextBox4.Text,fecha,TextBox6.Text,out service, out service1);
            if (service == true)
            {
                Label1.Text = "Sucess";
            }
            else
            {
                Label1.Text = "Error(502) - Intentalo de nuevo";
            }
        }

        protected void TextBox6_TextChanged(object sender, EventArgs e)
        {
    
        
        }
    }
}