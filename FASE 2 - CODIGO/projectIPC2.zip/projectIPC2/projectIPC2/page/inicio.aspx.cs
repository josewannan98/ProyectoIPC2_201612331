﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class inicio2 : System.Web.UI.Page
    {
        int notifs;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                    obtenernotificacion();
                    obtenerkarma();
                    obtenernotificacionasociacion();
                    obtenercontactos();
                    obtenermensajes();
                    obtenertareas();
                    obtenerproyectos();
                    Label19.Text = notifs.ToString();
                    Label20.Text = notifs.ToString();
                    obtenertareass();
                    obtenerproyectoss();
                    obtenerasociacioness();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
                
            }
            else
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
            }
           
           
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("Asociaciones.aspx");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Mis Proyectos y Tareas.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("Contactos.aspx");
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Proyectos.aspx");
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("Tareas.aspx");
        }
        public void obtenernotificacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenerNotificaciones(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length-1) ==4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[0].Replace('[', '\0');
                Label9.Text = md4;
                TextBox4.Text = notif[3];
            }
            else if ((notif.Length-1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length -1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length-1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length-1) == 0)
            {
                Label6.Visible = false;
                TextBox1.Visible = false;
                Image1.Visible = false;

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }

        }
        public void obtenerkarma()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int karma = inicio.obtenerkarma(Convert.ToInt32(Session["idusuario"].ToString()));
            Label2.Text = Convert.ToString(karma);
        }
        public void obtenernotificacionasociacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenernotificacionasosiacion(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length - 1) == 4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[2].Replace(']', '\0');
                Label13.Text = md4;
                TextBox8.Text = notif[3];
            }
            else if ((notif.Length - 1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 0)
            {
                Label10.Visible = false;
                TextBox5.Visible = false;
                Image5.Visible = false;

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }

        }
        public void obtenercontactos()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenercontactoscantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label14.Text = contact.ToString();
        }
        public void obtenermensajes()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenermensajecantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label3.Text = contact.ToString();
            Label17.Text = contact.ToString();
            Label18.Text = contact.ToString();
        }
        public void obtenerproyectos()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenerproyectoscantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label4.Text = contact.ToString();
        }
        public void obtenertareas()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenertareascantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label5.Text = contact.ToString();
        }
        public void obtenertareass()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenertareasss();
            Label21.Text = contact.ToString();
        }
        public void obtenerproyectoss()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenerprojectss();
            Label15.Text = contact.ToString();
        }
        public void obtenerasociacioness()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenerasociacionss();
            Label16.Text = contact.ToString();
        }

    }
    
}