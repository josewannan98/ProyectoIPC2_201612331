﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class salir1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["nickname"]!= null)
            {
                Label1.Text = Session["nickname"].ToString();
                Label2.Text = Session["nickname"].ToString();
            }
            else
            {
                Label1.Text = "no has iniciado sesion";
                Label2.Text = "no has iniciado sesion";
            }
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("login.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            if (Session["nickname"] != null)
            {
                if (TextBox1.Text.Equals(Session["contraseña"].ToString()))
                {
                    Response.Redirect("inicio.aspx");
                }
                else
                {
                    Label2.Text = "Contraseña Erronea";
                }
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }
    }
}