﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class login1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (Session["nickname"] != null)
                {
                    Response.Redirect("inicio.aspx");
                }
            }
                
               
              

            
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear iniciar = new ipc2.LoginyCrear();
            String usuario = iniciar.ingresarusuario(TextBox1.Text, TextBox2.Text);
            try
            {
                if (usuario != "Nope")
                {
                    Label2.Text = "sucess, [" + usuario + "]";

                    String[] ms = usuario.Split(',');
                    Session["idusuario"] = ms[0];
                    Session["nickname"] = ms[1];
                    Session["contraseña"] = TextBox2.Text;
                    Response.Redirect("inicio.aspx");
                }
                else if (usuario.Equals("Nope"))
                {

                    Label2.Text = "Error(506)";
                }
                else
                {
                    Label2.Text = "Error(502)";
                }
            }catch(Exception esd)
            {

            }
            
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear iniciar = new ipc2.LoginyCrear();
            String usuario = iniciar.recordarcontra(TextBox3.Text,TextBox4.Text);
            try
            {
                if (usuario != "Nope")
                {

                    Label1.Text = "sucess, " + usuario;
                    Label2.Text = "sucess, " + usuario;

                }
                else if (usuario.Equals("Nope"))
                {
                    Label1.Text = "Error(506)";
                    Label2.Text = "Error(506)";
                }
                else
                {
                    Label1.Text = "Error(506)";
                    Label2.Text = "Error(506)";
                }
            }
            catch(Exception easd)
            {

            }
           
        }
    }
}