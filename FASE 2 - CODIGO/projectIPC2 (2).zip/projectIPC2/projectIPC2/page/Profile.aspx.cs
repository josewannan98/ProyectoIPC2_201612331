﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class Profile : System.Web.UI.Page
    {
        int notifs;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                    Label3.Text = Session["nickname"].ToString();
                    obtenerdatosperfil();
                    obtenernotificacion();
                  
                    obtenernotificacionasociacion();
                 
                    obtenermensajes();
                    obtenerhabilidad();
                    obtenerconocimiento();
                  
                    Label19.Text = notifs.ToString();
                    Label20.Text = notifs.ToString();
                   
                   
                }
                else
                {
                    Response.Redirect("login.aspx");
                }

            }
            else
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
            }
        }
        public void obtenernotificacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenerNotificaciones(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length - 1) == 4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[0].Replace('[', '\0');
                Label9.Text = md4;
                TextBox4.Text = notif[3];
            }
            else if ((notif.Length - 1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length - 1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length - 1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length - 1) == 0)
            {
                Label6.Visible = false;
                TextBox1.Visible = false;
                Image1.Visible = false;

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }

        }
      
        public void obtenernotificacionasociacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenernotificacionasosiacion(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length - 1) == 4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[2].Replace(']', '\0');
                Label13.Text = md4;
                TextBox8.Text = notif[3];
            }
            else if ((notif.Length - 1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 0)
            {
                Label10.Visible = false;
                TextBox5.Visible = false;
                Image5.Visible = false;

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }

        }
     
        public void obtenermensajes()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenermensajecantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            
            Label17.Text = contact.ToString();
            Label18.Text = contact.ToString();
        }
      
        
        public void obtenerdatosperfil()
        {
            ipc2.LoginyCrear perfil = new ipc2.LoginyCrear();
            String perfils = perfil.obtenerprfils(Convert.ToInt32(Session["idusuario"].ToString()));
            if (perfils != "Nope")
            {
                String[] profile = perfils.Split('|');
                TextBox9.Text = profile[0].Replace('[', ' ');
                TextBox10.Text = profile[1];
                TextBox11.Text = profile[5].Replace(']',' ');
                String fecha = String.Format("{0:MM-dd-yy}", profile[3]);
                TextBox12.Text = fecha;
                TextBox13.Text = profile[2];
                TextBox14.Text = profile[4];
            }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            TextBox9.Enabled = true;
            TextBox10.Enabled = true;
            TextBox11.Enabled = true;
            TextBox12.Enabled = true;
            TextBox13.Enabled = true;
            TextBox14.Enabled = true;

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear perfil = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            String ms = TextBox12.Text;
            String fecha = String.Format("{0:yy-MM-dd}", ms);
            perfil.actualizarusuario(TextBox9.Text, TextBox10.Text, TextBox13.Text, fecha, TextBox14.Text, TextBox11.Text, Convert.ToInt32(Session["idusuario"].ToString()), out service, out service1);
            if (service == true)
            {
                Session.Abandon();
                Session.Clear();
                Response.Redirect("login.aspx");
            }
            else
            {
                Label4.Text = "Error(303) - No se puede realizar los cambios";
            }
        }
        public void obtenerhabilidad()
        {
            ipc2.LoginyCrear perfil = new ipc2.LoginyCrear();
            String perfils = perfil.obtenerhabilidad(Convert.ToInt32(Session["idusuario"].ToString()));
            if (perfils != "Nope")
            {
                String[] ls = perfils.Split(',');
                for(int a=0; a < ls.Length; a++)
                {
                    TextBox15.Text += ls[a] + '\n';
                }
            }
        }
        public void obtenerconocimiento()
        {
            ipc2.LoginyCrear perfil = new ipc2.LoginyCrear();
            String perfils = perfil.obtenerconocimiento(Convert.ToInt32(Session["idusuario"].ToString()));
            if (perfils != "Nope")
            {
                String[] ls = perfils.Split(',');
                for (int a = 0; a < ls.Length; a++)
                {
                    TextBox16.Text += ls[a] + '\n';
                }
            }
        }

    }
}