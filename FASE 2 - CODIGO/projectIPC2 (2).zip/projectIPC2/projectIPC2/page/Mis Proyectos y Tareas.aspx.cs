﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class Mis_Proyectos_y_Tareas : System.Web.UI.Page
    {
        int notifs;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();


                    obtenernotificacion();

                    obtenernotificacionasociacion();

                    obtenermensajes();

                    buscarproyecto();
                    buscartarea();
                    Label19.Text = notifs.ToString();
                    Label20.Text = notifs.ToString();


                }
                else
                {
                    Response.Redirect("login.aspx");
                }

            }
            else
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
            }
        }

        public void obtenernotificacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenerNotificaciones(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length - 1) == 4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[0].Replace('[', '\0');
                Label9.Text = md4;
                TextBox4.Text = notif[3];
            }
            else if ((notif.Length - 1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length - 1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length - 1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length - 1) == 0)
            {
                Label6.Visible = false;
                TextBox1.Visible = false;
                Image1.Visible = false;

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }

        }

        public void obtenernotificacionasociacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenernotificacionasosiacion(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length - 1) == 4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[2].Replace(']', '\0');
                Label13.Text = md4;
                TextBox8.Text = notif[3];
            }
            else if ((notif.Length - 1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 0)
            {
                Label10.Visible = false;
                TextBox5.Visible = false;
                Image5.Visible = false;

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }

        }

        public void obtenermensajes()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenermensajecantidad(Convert.ToInt32(Session["idusuario"].ToString()));

            Label17.Text = contact.ToString();
            Label18.Text = contact.ToString();
        }

        public void buscarproyecto()
        {
            ipc2.LoginyCrear init = new ipc2.LoginyCrear();
            String ontactos = init.proyectos();
            if (ontactos != "Nope")
            {
                String[] opp = ontactos.Split(',');
                if ((opp.Length - 1) == 1)
                {
                    String[] sd = opp[0].Split('|');
                    Label31.Text = sd[0].Replace('[', ' ');
                    Label2.Text = opp[0];
                    Button3.Visible = false;
                    Button4.Visible = false;
                    Button1.Visible = false;
                }
                else if ((opp.Length - 1) == 2)
                {
                    String[] sd = opp[0].Split('|');
                    Label31.Text = sd[0].Replace('[', ' ');
                    Label2.Text = opp[0];

                    String[] sd1 = opp[1].Split('|');
                    Label32.Text = sd1[0].Replace('[', ' ');
                    Label30.Text = opp[1];
                    Button4.Visible = false;
                    Button1.Visible = false;
                }
                else if ((opp.Length - 1) == 3)
                {
                    String[] sd = opp[0].Split('|');
                    Label31.Text = sd[0].Replace('[', ' ');
                    Label2.Text = opp[0];

                    String[] sd1 = opp[1].Split('|');
                    Label32.Text = sd1[0].Replace('[', ' ');
                    Label30.Text = opp[1];

                    String[] sd2 = opp[2].Split('|');
                    Label6.Text = sd2[0].Replace('[', ' ');
                    Label7.Text = opp[2];

                    Button4.Visible = false;

                }
                else if ((opp.Length - 1) == 4)
                {
                    String[] sd = opp[0].Split('|');
                    Label31.Text = sd[0].Replace('[', ' ');
                    Label2.Text = opp[0];

                    String[] sd1 = opp[1].Split('|');
                    Label32.Text = sd1[0].Replace('[', ' ');
                    Label30.Text = opp[1];

                    String[] sd2 = opp[2].Split('|');
                    Label6.Text = sd2[0].Replace('[', ' ');
                    Label7.Text = opp[2];

                    String[] sd3 = opp[3].Split('|');
                    Label8.Text = sd3[0].Replace('[', ' ');
                    Label9.Text = opp[3];

                }

            }
        }

        public void buscartarea()
        {
            ipc2.LoginyCrear init = new ipc2.LoginyCrear();
            String ontactos = init.tareas();
            if (ontactos != "Nope")
            {
                String[] opp = ontactos.Split(',');
                if ((opp.Length - 1) == 1)
                {
                    String[] sd = opp[0].Split('|');
                    Label15.Text = sd[0].Replace('[', ' ');
                    Label16.Text = opp[0];
                    Button3.Visible = false;
                    Button4.Visible = false;
                    Button1.Visible = false;
                }
                else if ((opp.Length - 1) == 2)
                {
                    String[] sd = opp[0].Split('|');
                    Label15.Text = sd[0].Replace('[', ' ');
                    Label16.Text = opp[0];

                    String[] sd1 = opp[1].Split('|');
                    Label21.Text = sd1[0].Replace('[', ' ');
                    Label22.Text = opp[1];
                    Button4.Visible = false;
                    Button1.Visible = false;
                }
                else if ((opp.Length - 1) == 3)
                {
                    String[] sd = opp[0].Split('|');
                    Label15.Text = sd[0].Replace('[', ' ');
                    Label16.Text = opp[0];

                    String[] sd1 = opp[1].Split('|');
                    Label21.Text = sd1[0].Replace('[', ' ');
                    Label22.Text = opp[1];

                    String[] sd2 = opp[2].Split('|');
                    Label23.Text = sd2[0].Replace('[', ' ');
                    Label24.Text = opp[2];

                    Button4.Visible = false;

                }
                else if ((opp.Length - 1) == 4)
                {
                    String[] sd = opp[0].Split('|');
                    Label15.Text = sd[0].Replace('[', ' ');
                    Label16.Text = opp[0];

                    String[] sd1 = opp[1].Split('|');
                    Label21.Text = sd1[0].Replace('[', ' ');
                    Label22.Text = opp[1];

                    String[] sd2 = opp[2].Split('|');
                    Label23.Text = sd2[0].Replace('[', ' ');
                    Label24.Text = opp[2];

                    String[] sd3 = opp[3].Split('|');
                    Label25.Text = sd3[0].Replace('[', ' ');
                    Label26.Text = opp[3];

                }

            }
        }


        protected void Button5_Click(object sender, EventArgs e)
        {
           
        }

        protected void Button6_Click(object sender, EventArgs e)
        {

        }

        protected void Button7_Click(object sender, EventArgs e)
        {

        }

        protected void Button8_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.unirse(Convert.ToInt32(Label31.Text),Convert.ToInt32(Session["idusuario"].ToString()),out service, out service1);
            if (service == true)
            {
                Response.Redirect("Mis Proyectos y Tareas.aspx");
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.unirse(Convert.ToInt32(Label32.Text), Convert.ToInt32(Session["idusuario"].ToString()), out service, out service1);
            if (service == true)
            {
                Response.Redirect("Mis Proyectos y Tareas.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.unirse(Convert.ToInt32(Label6.Text), Convert.ToInt32(Session["idusuario"].ToString()), out service, out service1);
            if (service == true)
            {
                Response.Redirect("Mis Proyectos y Tareas.aspx");
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.unirse(Convert.ToInt32(Label8.Text), Convert.ToInt32(Session["idusuario"].ToString()), out service, out service1);
            if (service == true)
            {
                Response.Redirect("Mis Proyectos y Tareas.aspx");
            }
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean services;
                Boolean services1;
                inisd.agregarTareass(Convert.ToInt32(Label33.Text),TextBox11.Text,Convert.ToInt32(Session["idusuario"].ToString()), out services, out services1);
                
            
                
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.sproyecto(TextBox9.Text, TextBox10.Text, TextBox11.Text, Convert.ToDouble(TextBox13.Text), TextBox14.Text, Convert.ToInt32(Session["idusuario"].ToString()), Convert.ToInt32(TextBox15.Text), out service, out service1);

        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.crearfinalproyecto(TextBox9.Text, Convert.ToInt32(Session["idusuario"].ToString()), out service, out service1);
            if (service == true)
            {
                Response.Redirect("Mis Proyectos y Tareas.aspx");
            }
        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            String contac = inisd.buscartarea(TextBox16.Text);
            if (contac != "Nope")
            {
                String[] asd = contac.Split(',');
                Label33.Text = asd[0];
                Label34.Text = asd[1];
            }
            else
            {
                Label34.Text = "Error";
            }
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            Response.Redirect("Mis Proyectos y Tareas.aspx");
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inisd.agregartarea(TextBox17.Text,TextBox18.Text, Convert.ToInt32(Session["idusuario"].ToString()),TextBox19.Text,Convert.ToDouble(TextBox20.Text),TextBox21.Text, out service, out service1);
            if (service == true)
            {
                Response.Redirect("Mis Proyectos y Tareas.aspx");
            }
        }
        public void buscasr()
        {
            ipc2.LoginyCrear inisd = new ipc2.LoginyCrear();
            String asdd = inisd.buscarsinpublicar(Convert.ToInt32(Session["idusuario"].ToString()));
            
            if (asdd != "Nope")
            {
                if (asdd != "")
                {
                    String[] ms = asdd.Split(',');
                    for (int a = 0; a < ms.Length; a++)
                    {
                        TextBox22.Text += ms[a] + '\n';
                    }
                }
                else
                {
                    TextBox22.Text = "No hay proyectos sin publicar";
                }
                
                
            }
        }
    }
}