﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projectIPC2.page
{
    public partial class inicioadmin : System.Web.UI.Page
    {
        int notifs;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                    obtenernotificacion();
                    obtenerkarma();
                    obtenernotificacionasociacion();
                    obtenercontactos();
                    obtenermensajes();
                    obtenertareas();
                    obtenerproyectos();
                    Label19.Text = notifs.ToString();
                    Label20.Text = notifs.ToString();
                    obtenertareass();
                    obtenerproyectoss();
                    obtenerasociacioness();
                    obtenerpublicaciones();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
                
            }
            else
            {
                if (Session["nickname"] != null)
                {
                    Label1.Text = Session["nickname"].ToString();
                }
                else
                {
                    Response.Redirect("login.aspx");
                }
            }
           
           
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("Asociaciones.aspx");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Mis Proyectos y Tareas.aspx");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("Contactos.aspx");
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Proyectos.aspx");
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("Tareas.aspx");
        }
        public void obtenernotificacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenerNotificaciones(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length-1) ==4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[0].Replace('[', '\0');
                Label9.Text = md4;
                TextBox4.Text = notif[3];
            }
            else if ((notif.Length-1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[0].Replace('[', '\0');
                Label8.Text = md3;
                TextBox3.Text = notif[2];

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length -1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[0].Replace('[', '\0');
                Label7.Text = md2;
                TextBox2.Text = notif[1];

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length-1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[0].Replace('[', '\0');
                Label6.Text = md1;
                TextBox1.Text = notif[0];

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }
            else if ((notif.Length-1) == 0)
            {
                Label6.Visible = false;
                TextBox1.Visible = false;
                Image1.Visible = false;

                Label7.Visible = false;
                TextBox2.Visible = false;
                Image2.Visible = false;

                Label8.Visible = false;
                TextBox3.Visible = false;
                Image3.Visible = false;

                Label9.Visible = false;
                TextBox4.Visible = false;
                Image4.Visible = false;
            }

        }
        public void obtenerkarma()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int karma = inicio.obtenerkarma(Convert.ToInt32(Session["idusuario"].ToString()));
            Label2.Text = Convert.ToString(karma);
        }
        public void obtenernotificacionasociacion()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            String notificacion = inicio.obtenernotificacionasosiacion(Convert.ToInt32(Session["idusuario"].ToString()));
            String[] notif = notificacion.Split(',');
            notifs += (notif.Length - 1);
            if ((notif.Length - 1) == 4)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                String[] asd4 = notif[3].Split('@');
                String md4 = asd4[2].Replace(']', '\0');
                Label13.Text = md4;
                TextBox8.Text = notif[3];
            }
            else if ((notif.Length - 1) == 3)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                String[] asd3 = notif[2].Split('@');
                String md3 = asd3[2].Replace(']', '\0');
                Label12.Text = md3;
                TextBox7.Text = notif[2];

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 2)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                String[] asd2 = notif[1].Split('@');
                String md2 = asd2[2].Replace(']', '\0');
                Label11.Text = md2;
                TextBox6.Text = notif[1];

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 1)
            {
                String[] asd1 = notif[0].Split('@');
                String md1 = asd1[2].Replace(']', '\0');
                Label10.Text = md1;
                TextBox5.Text = notif[0];

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }
            else if ((notif.Length - 1) == 0)
            {
                Label10.Visible = false;
                TextBox5.Visible = false;
                Image5.Visible = false;

                Label11.Visible = false;
                TextBox6.Visible = false;
                Image6.Visible = false;

                Label12.Visible = false;
                TextBox7.Visible = false;
                Image7.Visible = false;

                Label13.Visible = false;
                TextBox8.Visible = false;
                Image8.Visible = false;
            }

        }
        public void obtenercontactos()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenercontactoscantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label14.Text = contact.ToString();
        }
        public void obtenermensajes()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenermensajecantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label3.Text = contact.ToString();
            Label17.Text = contact.ToString();
            Label18.Text = contact.ToString();
        }
        public void obtenerproyectos()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenerproyectoscantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label4.Text = contact.ToString();
        }
        public void obtenertareas()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenertareascantidad(Convert.ToInt32(Session["idusuario"].ToString()));
            Label5.Text = contact.ToString();
        }
        public void obtenertareass()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenertareasss();
            Label21.Text = contact.ToString();
        }
        public void obtenerproyectoss()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenerprojectss();
            Label15.Text = contact.ToString();
        }
        public void obtenerasociacioness()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            int contact = inicio.obtenerasociacionss();
            Label16.Text = contact.ToString();
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean service;
            Boolean service1;
            inicio.insertarestado(text1.Text, Convert.ToInt32(Session["idusuario"].ToString()),out service, out service1);
            if (service == true)
            {
                Label22.Text = "Sucess";
                text1.Text = "";
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(502) - Intentalo de nuevo";
            }
        }

       
        protected void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }



    

        protected void Button8_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox14.Text, Convert.ToInt32(Label23.Text),Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
          
            inicio.insertarcomentario(TextBox16.Text, Convert.ToInt32(Label33.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox22.Text, Convert.ToInt32(Label43.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox28.Text, Convert.ToInt32(Label53.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox34.Text, Convert.ToInt32(Label63.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            Label22.Text = Label33.Text;
            inicio.insertarcomentario(TextBox40.Text, Convert.ToInt32(Label73.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button13_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox46.Text, Convert.ToInt32(Label83.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button14_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox52.Text, Convert.ToInt32(Label93.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            inicio.insertarcomentario(TextBox58.Text, Convert.ToInt32(Label103.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button16_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;
            
            inicio.insertarcomentario(TextBox64.Text, Convert.ToInt32(Label113.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button17_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;

            inicio.denunciarpublicacion(Convert.ToInt32(Label23.Text), out Service, out Service1);
                if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(603) - denuncia";
            }
        }
        public void obtenerpublicaciones()
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();

            String contact = inicio.obtenerpublicacion();
            if (contact != "Nope")
            {
                String[] amd = contact.Split(',');

                if ((amd.Length - 1) == 10)
                {
                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0];
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0];
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0];
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0];
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------
                    String[] publicacion4 = amd[4].Split('@');

                    String idpublicacion4 = publicacion4[0];
                    String publicacions4 = publicacion4[1];
                    String usuario4 = publicacion4[2].Replace(']', '\0');

                    String comenta4 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion4));
                    if (comenta4 != "Nope")
                    {
                        String[] comentar = comenta4.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label71.Text = idcomentario3;
                            Label72.Text = idusuarios3;

                            TextBox38.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;



                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label65.Visible = false;
                            Label66.Visible = false;

                            TextBox35.Visible = false;


                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                    }
                    else
                    {
                        Div4.Visible = false;
                    }

                    Label63.Text = idpublicacion4;
                    Label64.Text = usuario4;
                    TextBox33.Text = publicacions4;
                    //---------
                    String[] publicacion5 = amd[5].Split('@');

                    String idpublicacion5 = publicacion5[0];
                    String publicacions5 = publicacion5[1];
                    String usuario5 = publicacion5[2].Replace(']', '\0');

                    String comenta5 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion5));
                    if (comenta5 != "Nope")
                    {
                        String[] comentar = comenta5.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label81.Text = idcomentario3;
                            Label82.Text = idusuarios3;

                            TextBox44.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;



                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label75.Visible = false;
                            Label76.Visible = false;

                            TextBox41.Visible = false;


                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                    }
                    else
                    {
                        Div5.Visible = false;
                    }

                    Label73.Text = idpublicacion5;
                    Label74.Text = usuario5;
                    TextBox39.Text = publicacions5;
                    //----------
                    String[] publicacion6 = amd[6].Split('@');

                    String idpublicacion6 = publicacion6[0];
                    String publicacions6 = publicacion6[1];
                    String usuario6 = publicacion6[2].Replace(']', '\0');

                    String comenta6 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion6));
                    if (comenta6 != "Nope")
                    {
                        String[] comentar = comenta6.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label91.Text = idcomentario3;
                            Label92.Text = idusuarios3;

                            TextBox50.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;



                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label85.Visible = false;
                            Label86.Visible = false;

                            TextBox47.Visible = false;


                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                    }
                    else
                    {
                        Div6.Visible = false;
                    }

                    Label83.Text = idpublicacion6;
                    Label84.Text = usuario6;
                    TextBox45.Text = publicacions6;
                    //--------
                    String[] publicacion7 = amd[7].Split('@');

                    String idpublicacion7 = publicacion7[0];
                    String publicacions7 = publicacion7[1];
                    String usuario7 = publicacion7[2].Replace(']', '\0');

                    String comenta7 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion7));
                    if (comenta7 != "Nope")
                    {
                        String[] comentar = comenta7.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label99.Text = idcomentario2;
                            Label100.Text = idusuarios2;

                            TextBox55.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label101.Text = idcomentario3;
                            Label102.Text = idusuarios3;

                            TextBox56.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label99.Text = idcomentario2;
                            Label100.Text = idusuarios2;

                            TextBox55.Text = comentarios2;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;



                            Label97.Visible = false;
                            Label98.Visible = false;

                            TextBox54.Visible = false;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label95.Visible = false;
                            Label96.Visible = false;

                            TextBox53.Visible = false;


                            Label97.Visible = false;
                            Label98.Visible = false;

                            TextBox54.Visible = false;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                    }
                    else
                    {
                        Div7.Visible = false;
                    }

                    Label93.Text = idpublicacion7;
                    Label94.Text = usuario7;
                    TextBox51.Text = publicacions7;
                    //----------
                    String[] publicacion8 = amd[8].Split('@');

                    String idpublicacion8 = publicacion8[0];
                    String publicacions8 = publicacion8[1];
                    String usuario8 = publicacion8[2].Replace(']', '\0');

                    String comenta8 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion8));
                    if (comenta8 != "Nope")
                    {
                        String[] comentar = comenta8.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label107.Text = idcomentario1;
                            Label108.Text = idusuarios1;

                            TextBox60.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label109.Text = idcomentario2;
                            Label110.Text = idusuarios2;

                            TextBox61.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label111.Text = idcomentario3;
                            Label112.Text = idusuarios3;

                            TextBox62.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label107.Text = idcomentario1;
                            Label108.Text = idusuarios1;

                            TextBox60.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label109.Text = idcomentario2;
                            Label110.Text = idusuarios2;

                            TextBox61.Text = comentarios2;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label107.Text = idcomentario1;
                            Label108.Text = idusuarios1;

                            TextBox60.Text = comentarios1;



                            Label109.Visible = false;
                            Label110.Visible = false;

                            TextBox61.Visible = false;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;



                            Label107.Visible = false;
                            Label108.Visible = false;

                            TextBox60.Visible = false;



                            Label109.Visible = false;
                            Label110.Visible = false;

                            TextBox61.Visible = false;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label105.Visible = false;
                            Label106.Visible = false;

                            TextBox59.Visible = false;


                            Label107.Visible = false;
                            Label108.Visible = false;

                            TextBox60.Visible = false;



                            Label109.Visible = false;
                            Label110.Visible = false;

                            TextBox61.Visible = false;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                    }
                    else
                    {
                        Div8.Visible = false;
                    }

                    Label103.Text = idpublicacion8;
                    Label104.Text = usuario8;
                    TextBox57.Text = publicacions8;
                    //-----------
                    String[] publicacion9 = amd[9].Split('@');

                    String idpublicacion9 = publicacion9[0];
                    String publicacions9 = publicacion9[1];
                    String usuario9 = publicacion9[2].Replace(']', '\0');

                    String comenta9 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion9));
                    if (comenta9 != "Nope")
                    {
                        String[] comentar = comenta9.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label115.Text = idcomentario;
                            Label116.Text = idusuarios;

                            TextBox65.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label117.Text = idcomentario1;
                            Label118.Text = idusuarios1;

                            TextBox66.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label119.Text = idcomentario2;
                            Label120.Text = idusuarios2;

                            TextBox67.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label121.Text = idcomentario3;
                            Label122.Text = idusuarios3;

                            TextBox68.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label115.Text = idcomentario;
                            Label116.Text = idusuarios;

                            TextBox65.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label117.Text = idcomentario1;
                            Label118.Text = idusuarios1;

                            TextBox66.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label119.Text = idcomentario2;
                            Label120.Text = idusuarios2;

                            TextBox67.Text = comentarios2;



                            Label121.Visible = false;
                            Label122.Visible = false;

                            TextBox68.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label115.Text = idcomentario;
                            Label116.Text = idusuarios;

                            TextBox65.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label117.Text = idcomentario1;
                            Label118.Text = idusuarios1;

                            TextBox66.Text = comentarios1;



                            Label119.Visible = false;
                            Label120.Visible = false;

                            TextBox67.Visible = false;



                            Label121.Visible = false;
                            Label122.Visible = false;

                            TextBox68.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label115.Text = idcomentario;
                            Label116.Text = idusuarios;

                            TextBox65.Text = comentarios;



                            Label117.Visible = false;
                            Label118.Visible = false;

                            TextBox66.Visible = false;



                            Label119.Visible = false;
                            Label120.Visible = false;

                            TextBox67.Visible = false;



                            Label121.Visible = false;
                            Label122.Visible = false;

                            TextBox68.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label115.Visible = false;
                            Label116.Visible = false;

                            TextBox65.Visible = false;


                            Label117.Visible = false;
                            Label118.Visible = false;

                            TextBox66.Visible = false;



                            Label119.Visible = false;
                            Label120.Visible = false;

                            TextBox67.Visible = false;



                            Label121.Visible = false;
                            Label122.Visible = false;

                            TextBox68.Visible = false;
                        }
                    }
                    else
                    {
                        Div9.Visible = false;
                    }

                    Label113.Text = idpublicacion9;
                    Label114.Text = usuario9;
                    TextBox63.Text = publicacions9;
                }     //yas
                else if ((amd.Length - 1) == 9)
                {

                    conte10.Visible = false;


                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0];
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0];
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0];
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0];
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------
                    String[] publicacion4 = amd[4].Split('@');

                    String idpublicacion4 = publicacion4[0];
                    String publicacions4 = publicacion4[1];
                    String usuario4 = publicacion4[2].Replace(']', '\0');

                    String comenta4 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion4));
                    if (comenta4 != "Nope")
                    {
                        String[] comentar = comenta4.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label71.Text = idcomentario3;
                            Label72.Text = idusuarios3;

                            TextBox38.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;



                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label65.Visible = false;
                            Label66.Visible = false;

                            TextBox35.Visible = false;


                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                    }
                    else
                    {
                        Div4.Visible = false;
                    }

                    Label63.Text = idpublicacion4;
                    Label64.Text = usuario4;
                    TextBox33.Text = publicacions4;
                    //---------
                    String[] publicacion5 = amd[5].Split('@');

                    String idpublicacion5 = publicacion5[0];
                    String publicacions5 = publicacion5[1];
                    String usuario5 = publicacion5[2].Replace(']', '\0');

                    String comenta5 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion5));
                    if (comenta5 != "Nope")
                    {
                        String[] comentar = comenta5.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label81.Text = idcomentario3;
                            Label82.Text = idusuarios3;

                            TextBox44.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;



                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label75.Visible = false;
                            Label76.Visible = false;

                            TextBox41.Visible = false;


                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                    }
                    else
                    {
                        Div5.Visible = false;
                    }

                    Label73.Text = idpublicacion5;
                    Label74.Text = usuario5;
                    TextBox39.Text = publicacions5;
                    //----------
                    String[] publicacion6 = amd[6].Split('@');

                    String idpublicacion6 = publicacion6[0];
                    String publicacions6 = publicacion6[1];
                    String usuario6 = publicacion6[2].Replace(']', '\0');

                    String comenta6 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion6));
                    if (comenta6 != "Nope")
                    {
                        String[] comentar = comenta6.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label91.Text = idcomentario3;
                            Label92.Text = idusuarios3;

                            TextBox50.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;



                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label85.Visible = false;
                            Label86.Visible = false;

                            TextBox47.Visible = false;


                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                    }
                    else
                    {
                        Div6.Visible = false;
                    }

                    Label83.Text = idpublicacion6;
                    Label84.Text = usuario6;
                    TextBox45.Text = publicacions6;
                    //--------
                    String[] publicacion7 = amd[7].Split('@');

                    String idpublicacion7 = publicacion7[0].Replace('[', '\0');
                    String publicacions7 = publicacion7[1];
                    String usuario7 = publicacion7[2].Replace(']', '\0');

                    String comenta7 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion7));
                    if (comenta7 != "Nope")
                    {
                        String[] comentar = comenta7.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label99.Text = idcomentario2;
                            Label100.Text = idusuarios2;

                            TextBox55.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label101.Text = idcomentario3;
                            Label102.Text = idusuarios3;

                            TextBox56.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label99.Text = idcomentario2;
                            Label100.Text = idusuarios2;

                            TextBox55.Text = comentarios2;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;



                            Label97.Visible = false;
                            Label98.Visible = false;

                            TextBox54.Visible = false;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label95.Visible = false;
                            Label96.Visible = false;

                            TextBox53.Visible = false;


                            Label97.Visible = false;
                            Label98.Visible = false;

                            TextBox54.Visible = false;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                    }
                    else
                    {
                        Div7.Visible = false;
                    }

                    Label93.Text = idpublicacion7;
                    Label94.Text = usuario7;
                    TextBox51.Text = publicacions7;
                    //----------
                    String[] publicacion8 = amd[8].Split('@');

                    String idpublicacion8 = publicacion8[0].Replace('[', '\0');
                    String publicacions8 = publicacion8[1];
                    String usuario8 = publicacion8[2].Replace(']', '\0');

                    String comenta8 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion8));
                    if (comenta8 != "Nope")
                    {
                        String[] comentar = comenta8.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label107.Text = idcomentario1;
                            Label108.Text = idusuarios1;

                            TextBox60.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label109.Text = idcomentario2;
                            Label110.Text = idusuarios2;

                            TextBox61.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label111.Text = idcomentario3;
                            Label112.Text = idusuarios3;

                            TextBox62.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label107.Text = idcomentario1;
                            Label108.Text = idusuarios1;

                            TextBox60.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label109.Text = idcomentario2;
                            Label110.Text = idusuarios2;

                            TextBox61.Text = comentarios2;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label107.Text = idcomentario1;
                            Label108.Text = idusuarios1;

                            TextBox60.Text = comentarios1;



                            Label109.Visible = false;
                            Label110.Visible = false;

                            TextBox61.Visible = false;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label105.Text = idcomentario;
                            Label106.Text = idusuarios;

                            TextBox59.Text = comentarios;



                            Label107.Visible = false;
                            Label108.Visible = false;

                            TextBox60.Visible = false;



                            Label109.Visible = false;
                            Label110.Visible = false;

                            TextBox61.Visible = false;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label105.Visible = false;
                            Label106.Visible = false;

                            TextBox59.Visible = false;


                            Label107.Visible = false;
                            Label108.Visible = false;

                            TextBox60.Visible = false;



                            Label109.Visible = false;
                            Label110.Visible = false;

                            TextBox61.Visible = false;



                            Label111.Visible = false;
                            Label112.Visible = false;

                            TextBox62.Visible = false;
                        }
                    }
                    else
                    {
                        Div8.Visible = false;
                    }

                    Label103.Text = idpublicacion8;
                    Label104.Text = usuario8;
                    TextBox57.Text = publicacions8;
                    //-----------

                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                } //yas
                else if ((amd.Length - 1) == 8)
                {


                    conte9.Visible = false;
                    conte10.Visible = false;


                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0];
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0];
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0];
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0];
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------
                    String[] publicacion4 = amd[4].Split('@');

                    String idpublicacion4 = publicacion4[0];
                    String publicacions4 = publicacion4[1];
                    String usuario4 = publicacion4[2].Replace(']', '\0');

                    String comenta4 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion4));
                    if (comenta4 != "Nope")
                    {
                        String[] comentar = comenta4.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label71.Text = idcomentario3;
                            Label72.Text = idusuarios3;

                            TextBox38.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario;
                            Label68.Text = idusuarios;

                            TextBox36.Text = comentarios;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;



                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label65.Visible = false;
                            Label66.Visible = false;

                            TextBox35.Visible = false;


                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                    }
                    else
                    {
                        Div4.Visible = false;
                    }

                    Label63.Text = idpublicacion4;
                    Label64.Text = usuario4;
                    TextBox33.Text = publicacions4;
                    //---------
                    String[] publicacion5 = amd[5].Split('@');

                    String idpublicacion5 = publicacion5[0];
                    String publicacions5 = publicacion5[1];
                    String usuario5 = publicacion5[2].Replace(']', '\0');

                    String comenta5 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion5));
                    if (comenta5 != "Nope")
                    {
                        String[] comentar = comenta5.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label81.Text = idcomentario3;
                            Label82.Text = idusuarios3;

                            TextBox44.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;



                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label75.Visible = false;
                            Label76.Visible = false;

                            TextBox41.Visible = false;


                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                    }
                    else
                    {
                        Div5.Visible = false;
                    }

                    Label73.Text = idpublicacion5;
                    Label74.Text = usuario5;
                    TextBox39.Text = publicacions5;
                    //----------
                    String[] publicacion6 = amd[6].Split('@');

                    String idpublicacion6 = publicacion6[0];
                    String publicacions6 = publicacion6[1];
                    String usuario6 = publicacion6[2].Replace(']', '\0');

                    String comenta6 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion6));
                    if (comenta6 != "Nope")
                    {
                        String[] comentar = comenta6.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label91.Text = idcomentario3;
                            Label92.Text = idusuarios3;

                            TextBox50.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;



                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label85.Visible = false;
                            Label86.Visible = false;

                            TextBox47.Visible = false;


                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                    }
                    else
                    {
                        Div6.Visible = false;
                    }

                    Label83.Text = idpublicacion6;
                    Label84.Text = usuario6;
                    TextBox45.Text = publicacions6;
                    //--------
                    String[] publicacion7 = amd[7].Split('@');

                    String idpublicacion7 = publicacion7[0].Replace('[', '\0');
                    String publicacions7 = publicacion7[1];
                    String usuario7 = publicacion7[2].Replace(']', '\0');

                    String comenta7 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion7));
                    if (comenta7 != "Nope")
                    {
                        String[] comentar = comenta7.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label99.Text = idcomentario2;
                            Label100.Text = idusuarios2;

                            TextBox55.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label101.Text = idcomentario3;
                            Label102.Text = idusuarios3;

                            TextBox56.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label99.Text = idcomentario2;
                            Label100.Text = idusuarios2;

                            TextBox55.Text = comentarios2;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label97.Text = idcomentario1;
                            Label98.Text = idusuarios1;

                            TextBox54.Text = comentarios1;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label95.Text = idcomentario;
                            Label96.Text = idusuarios;

                            TextBox53.Text = comentarios;



                            Label97.Visible = false;
                            Label98.Visible = false;

                            TextBox54.Visible = false;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label95.Visible = false;
                            Label96.Visible = false;

                            TextBox53.Visible = false;


                            Label97.Visible = false;
                            Label98.Visible = false;

                            TextBox54.Visible = false;



                            Label99.Visible = false;
                            Label100.Visible = false;

                            TextBox55.Visible = false;



                            Label101.Visible = false;
                            Label102.Visible = false;

                            TextBox56.Visible = false;
                        }
                    }
                    else
                    {
                        Div7.Visible = false;
                    }

                    Label93.Text = idpublicacion7;
                    Label94.Text = usuario7;
                    TextBox51.Text = publicacions7;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                } //yas
                else if ((amd.Length - 1) == 7)
                {


                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;



                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0];
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0];
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0];
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0];
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------
                    String[] publicacion4 = amd[4].Split('@');

                    String idpublicacion4 = publicacion4[0];
                    String publicacions4 = publicacion4[1];
                    String usuario4 = publicacion4[2].Replace(']', '\0');

                    String comenta4 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion4));
                    if (comenta4 != "Nope")
                    {
                        String[] comentar = comenta4.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label71.Text = idcomentario3;
                            Label72.Text = idusuarios3;

                            TextBox38.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;



                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label65.Visible = false;
                            Label66.Visible = false;

                            TextBox35.Visible = false;


                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                    }
                    else
                    {
                        Div4.Visible = false;
                    }

                    Label63.Text = idpublicacion4;
                    Label64.Text = usuario4;
                    TextBox33.Text = publicacions4;
                    //---------
                    String[] publicacion5 = amd[5].Split('@');

                    String idpublicacion5 = publicacion5[0];
                    String publicacions5 = publicacion5[1];
                    String usuario5 = publicacion5[2].Replace(']', '\0');

                    String comenta5 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion5));
                    if (comenta5 != "Nope")
                    {
                        String[] comentar = comenta5.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label81.Text = idcomentario3;
                            Label82.Text = idusuarios3;

                            TextBox44.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;



                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label75.Visible = false;
                            Label76.Visible = false;

                            TextBox41.Visible = false;


                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                    }
                    else
                    {
                        Div5.Visible = false;
                    }

                    Label73.Text = idpublicacion5;
                    Label74.Text = usuario5;
                    TextBox39.Text = publicacions5;
                    //----------
                    String[] publicacion6 = amd[6].Split('@');

                    String idpublicacion6 = publicacion6[0];
                    String publicacions6 = publicacion6[1];
                    String usuario6 = publicacion6[2].Replace(']', '\0');

                    String comenta6 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion6));
                    if (comenta6 != "Nope")
                    {
                        String[] comentar = comenta6.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label91.Text = idcomentario3;
                            Label92.Text = idusuarios3;

                            TextBox50.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label89.Text = idcomentario2;
                            Label90.Text = idusuarios2;

                            TextBox49.Text = comentarios2;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label87.Text = idcomentario1;
                            Label88.Text = idusuarios1;

                            TextBox48.Text = comentarios1;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label85.Text = idcomentario;
                            Label86.Text = idusuarios;

                            TextBox47.Text = comentarios;



                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label85.Visible = false;
                            Label86.Visible = false;

                            TextBox47.Visible = false;


                            Label87.Visible = false;
                            Label88.Visible = false;

                            TextBox48.Visible = false;



                            Label89.Visible = false;
                            Label90.Visible = false;

                            TextBox49.Visible = false;



                            Label91.Visible = false;
                            Label92.Visible = false;

                            TextBox50.Visible = false;
                        }
                    }
                    else
                    {
                        Div6.Visible = false;
                    }

                    Label83.Text = idpublicacion6;
                    Label84.Text = usuario6;
                    TextBox45.Text = publicacions6;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                } //yas
                else if ((amd.Length - 1) == 6)
                {

                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;



                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0].Replace('[', '\0');
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0].Replace('[', '\0');
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0].Replace('[', '\0');
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0].Replace('[', '\0');
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------
                    String[] publicacion4 = amd[4].Split('@');

                    String idpublicacion4 = publicacion4[0].Replace('[', '\0');
                    String publicacions4 = publicacion4[1];
                    String usuario4 = publicacion4[2].Replace(']', '\0');

                    String comenta4 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion4));
                    if (comenta4 != "Nope")
                    {
                        String[] comentar = comenta4.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label71.Text = idcomentario3;
                            Label72.Text = idusuarios3;

                            TextBox38.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;



                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label65.Visible = false;
                            Label66.Visible = false;

                            TextBox35.Visible = false;


                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                    }
                    else
                    {
                        Div4.Visible = false;
                    }

                    Label63.Text = idpublicacion4;
                    Label64.Text = usuario4;
                    TextBox33.Text = publicacions4;
                    //---------
                    String[] publicacion5 = amd[5].Split('@');

                    String idpublicacion5 = publicacion5[0].Replace('[', '\0');
                    String publicacions5 = publicacion5[1];
                    String usuario5 = publicacion5[2].Replace(']', '\0');

                    String comenta5 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion5));
                    if (comenta5 != "Nope")
                    {
                        String[] comentar = comenta5.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label81.Text = idcomentario3;
                            Label82.Text = idusuarios3;

                            TextBox44.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label79.Text = idcomentario2;
                            Label80.Text = idusuarios2;

                            TextBox43.Text = comentarios2;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label77.Text = idcomentario1;
                            Label78.Text = idusuarios1;

                            TextBox42.Text = comentarios1;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label75.Text = idcomentario;
                            Label76.Text = idusuarios;

                            TextBox41.Text = comentarios;



                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label75.Visible = false;
                            Label76.Visible = false;

                            TextBox41.Visible = false;


                            Label77.Visible = false;
                            Label78.Visible = false;

                            TextBox42.Visible = false;



                            Label79.Visible = false;
                            Label80.Visible = false;

                            TextBox43.Visible = false;



                            Label81.Visible = false;
                            Label82.Visible = false;

                            TextBox44.Visible = false;
                        }
                    }
                    else
                    {
                        Div5.Visible = false;
                    }

                    Label73.Text = idpublicacion5;
                    Label74.Text = usuario5;
                    TextBox39.Text = publicacions5;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------

                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                } //yas
                else if ((amd.Length - 1) == 5)
                {


                    conte6.Visible = false;
                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;


                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0].Replace('[', '\0');
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0].Replace('[', '\0');
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0].Replace('[', '\0');
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0].Replace('[', '\0');
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------
                    String[] publicacion4 = amd[4].Split('@');

                    String idpublicacion4 = publicacion4[0].Replace('[', '\0');
                    String publicacions4 = publicacion4[1];
                    String usuario4 = publicacion4[2].Replace(']', '\0');

                    String comenta4 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion4));
                    if (comenta4 != "Nope")
                    {
                        String[] comentar = comenta4.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label71.Text = idcomentario3;
                            Label72.Text = idusuarios3;

                            TextBox38.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label69.Text = idcomentario2;
                            Label70.Text = idusuarios2;

                            TextBox37.Text = comentarios2;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label67.Text = idcomentario1;
                            Label68.Text = idusuarios1;

                            TextBox36.Text = comentarios1;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label65.Text = idcomentario;
                            Label66.Text = idusuarios;

                            TextBox35.Text = comentarios;



                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label65.Visible = false;
                            Label66.Visible = false;

                            TextBox35.Visible = false;


                            Label67.Visible = false;
                            Label68.Visible = false;

                            TextBox36.Visible = false;



                            Label69.Visible = false;
                            Label70.Visible = false;

                            TextBox37.Visible = false;



                            Label71.Visible = false;
                            Label72.Visible = false;

                            TextBox38.Visible = false;
                        }
                    }
                    else
                    {
                        Div4.Visible = false;
                    }

                    Label63.Text = idpublicacion4;
                    Label64.Text = usuario4;
                    TextBox33.Text = publicacions4;
                    //---------

                    Label73.Visible = false;
                    Label74.Visible = false;
                    TextBox39.Visible = false;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                }  //yas
                else if ((amd.Length - 1) == 4)
                {

                    conte5.Visible = false;
                    conte6.Visible = false;
                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;


                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0].Replace('[', '\0');
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0].Replace('[', '\0');
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario;
                            Label38.Text = idusuarios;

                            TextBox18.Text = comentarios;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0].Replace('[', '\0');
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------
                    String[] publicacion3 = amd[3].Split('@');

                    String idpublicacion3 = publicacion3[0].Replace('[', '\0');
                    String publicacions3 = publicacion3[1];
                    String usuario3 = publicacion3[2].Replace(']', '\0');

                    String comenta3 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion3));
                    if (comenta3 != "Nope")
                    {
                        String[] comentar = comenta3.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label61.Text = idcomentario3;
                            Label62.Text = idusuarios3;

                            TextBox32.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label59.Text = idcomentario2;
                            Label60.Text = idusuarios2;

                            TextBox31.Text = comentarios2;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label57.Text = idcomentario1;
                            Label58.Text = idusuarios1;

                            TextBox30.Text = comentarios1;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label55.Text = idcomentario;
                            Label56.Text = idusuarios;

                            TextBox29.Text = comentarios;



                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label55.Visible = false;
                            Label56.Visible = false;

                            TextBox29.Visible = false;


                            Label57.Visible = false;
                            Label58.Visible = false;

                            TextBox30.Visible = false;



                            Label59.Visible = false;
                            Label60.Visible = false;

                            TextBox31.Visible = false;



                            Label61.Visible = false;
                            Label62.Visible = false;

                            TextBox32.Visible = false;
                        }
                    }
                    else
                    {
                        Div3.Visible = false;
                    }

                    Label53.Text = idpublicacion3;
                    Label54.Text = usuario3;
                    TextBox27.Text = publicacions3;
                    //---------

                    Label63.Visible = false;
                    Label64.Visible = false;
                    TextBox33.Visible = false;
                    //---------

                    Label73.Visible = false;
                    Label74.Visible = false;
                    TextBox39.Visible = false;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                }  //yas
                else if ((amd.Length - 1) == 3)
                {

                    conte4.Visible = false;
                    conte5.Visible = false;
                    conte6.Visible = false;
                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;

                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0].Replace('[', '\0');
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0].Replace('[', '\0');
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------
                    String[] publicacion2 = amd[2].Split('@');

                    String idpublicacion2 = publicacion2[0].Replace('[', '\0');
                    String publicacions2 = publicacion2[1];
                    String usuario2 = publicacion2[2].Replace(']', '\0');

                    String comenta2 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion2));
                    if (comenta2 != "Nope")
                    {
                        String[] comentar = comenta2.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label51.Text = idcomentario3;
                            Label52.Text = idusuarios3;

                            TextBox25.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label49.Text = idcomentario2;
                            Label50.Text = idusuarios2;

                            TextBox25.Text = comentarios2;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label47.Text = idcomentario1;
                            Label48.Text = idusuarios1;

                            TextBox24.Text = comentarios1;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label45.Text = idcomentario;
                            Label46.Text = idusuarios;

                            TextBox23.Text = comentarios;



                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label45.Visible = false;
                            Label46.Visible = false;

                            TextBox23.Visible = false;


                            Label47.Visible = false;
                            Label48.Visible = false;

                            TextBox24.Visible = false;



                            Label49.Visible = false;
                            Label50.Visible = false;

                            TextBox25.Visible = false;



                            Label51.Visible = false;
                            Label52.Visible = false;

                            TextBox26.Visible = false;
                        }
                    }
                    else
                    {
                        Div2.Visible = false;
                    }

                    Label43.Text = idpublicacion2;
                    Label44.Text = usuario2;
                    TextBox21.Text = publicacions2;
                    //------


                    Label53.Visible = false;
                    Label54.Visible = false;
                    TextBox27.Visible = false;
                    //---------

                    Label63.Visible = false;
                    Label64.Visible = false;
                    TextBox33.Visible = false;
                    //---------

                    Label73.Visible = false;
                    Label74.Visible = false;
                    TextBox39.Visible = false;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                }  //yas
                else if ((amd.Length - 1) == 2)
                {

                    conte3.Visible = false;
                    conte4.Visible = false;
                    conte5.Visible = false;
                    conte6.Visible = false;
                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;

                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0].Replace('[', '\0');
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------
                    String[] publicacion1 = amd[1].Split('@');

                    String idpublicacion1 = publicacion1[0].Replace('[', '\0');
                    String publicacions1 = publicacion1[1];
                    String usuario1 = publicacion1[2].Replace(']', '\0');

                    String comenta1 = inicio.obtenercomentario(Convert.ToInt32(idpublicacion1));
                    if (comenta1 != "Nope")
                    {
                        String[] comentar = comenta1.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label41.Text = idcomentario3;
                            Label42.Text = idusuarios3;

                            TextBox20.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label39.Text = idcomentario2;
                            Label40.Text = idusuarios2;

                            TextBox19.Text = comentarios2;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label37.Text = idcomentario1;
                            Label38.Text = idusuarios1;

                            TextBox18.Text = comentarios1;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label35.Text = idcomentario;
                            Label36.Text = idusuarios;

                            TextBox17.Text = comentarios;



                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label35.Visible = false;
                            Label36.Visible = false;

                            TextBox17.Visible = false;


                            Label37.Visible = false;
                            Label38.Visible = false;

                            TextBox18.Visible = false;



                            Label39.Visible = false;
                            Label40.Visible = false;

                            TextBox19.Visible = false;



                            Label41.Visible = false;
                            Label42.Visible = false;

                            TextBox20.Visible = false;
                        }
                    }
                    else
                    {
                        Div1.Visible = false;
                    }


                    Label33.Text = idpublicacion1;
                    Label34.Text = usuario1;
                    TextBox15.Text = publicacions1;
                    //--------


                    Label43.Visible = false;
                    Label44.Visible = false;
                    TextBox21.Visible = false;
                    //------


                    Label53.Visible = false;
                    Label54.Visible = false;
                    TextBox27.Visible = false;
                    //---------

                    Label63.Visible = false;
                    Label64.Visible = false;
                    TextBox33.Visible = false;
                    //---------

                    Label73.Visible = false;
                    Label74.Visible = false;
                    TextBox39.Visible = false;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                }  //yas
                else if ((amd.Length - 1) == 1)
                {

                    conte2.Visible = false;
                    conte3.Visible = false;
                    conte4.Visible = false;
                    conte5.Visible = false;
                    conte6.Visible = false;
                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;
                    String[] publicacion = amd[0].Split('@');

                    String idpublicacion = publicacion[0].Replace('[', '\0');
                    String publicacions = publicacion[1];
                    String usuario = publicacion[2].Replace(']', '\0');

                    String comenta = inicio.obtenercomentario(Convert.ToInt32(idpublicacion));
                    if (comenta != "Nope")
                    {
                        String[] comentar = comenta.Split(',');
                        if ((comentar.Length - 1) == 4)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;

                            String[] comentario3 = comentar[3].Split('@');

                            String idcomentario3 = comentario3[0].Replace('[', '\0');
                            String comentarios3 = comentario3[1];
                            String idusuarios3 = comentario3[2].Replace(']', '\0');

                            Label31.Text = idcomentario3;
                            Label32.Text = idusuarios3;

                            TextBox13.Text = comentarios3;
                        }
                        else if ((comentar.Length - 1) == 3)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;

                            String[] comentario2 = comentar[2].Split('@');

                            String idcomentario2 = comentario2[0].Replace('[', '\0');
                            String comentarios2 = comentario2[1];
                            String idusuarios2 = comentario2[2].Replace(']', '\0');

                            Label29.Text = idcomentario2;
                            Label30.Text = idusuarios2;

                            TextBox12.Text = comentarios2;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 2)
                        {
                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;

                            String[] comentario1 = comentar[1].Split('@');

                            String idcomentario1 = comentario1[0].Replace('[', '\0');
                            String comentarios1 = comentario1[1];
                            String idusuarios1 = comentario1[2].Replace(']', '\0');

                            Label27.Text = idcomentario1;
                            Label28.Text = idusuarios1;

                            TextBox11.Text = comentarios1;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 1)
                        {


                            String[] comentario = comentar[0].Split('@');

                            String idcomentario = comentario[0].Replace('[', '\0');
                            String comentarios = comentario[1];
                            String idusuarios = comentario[2].Replace(']', '\0');

                            Label25.Text = idcomentario;
                            Label26.Text = idusuarios;

                            TextBox10.Text = comentarios;



                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                        else if ((comentar.Length - 1) == 0)
                        {
                            Label25.Visible = false;
                            Label26.Visible = false;

                            TextBox10.Visible = false;


                            Label27.Visible = false;
                            Label28.Visible = false;

                            TextBox11.Visible = false;



                            Label29.Visible = false;
                            Label30.Visible = false;

                            TextBox12.Visible = false;



                            Label31.Visible = false;
                            Label32.Visible = false;

                            TextBox13.Visible = false;
                        }
                    }
                    else
                    {
                        Div10.Visible = false;
                    }

                    Label23.Text = idpublicacion;
                    Label24.Text = usuario;
                    TextBox9.Text = publicacions;
                    //--------

                    Label33.Visible = false;
                    Label34.Visible = false;
                    TextBox15.Visible = false;
                    //--------


                    Label43.Visible = false;
                    Label44.Visible = false;
                    TextBox21.Visible = false;
                    //------


                    Label53.Visible = false;
                    Label54.Visible = false;
                    TextBox27.Visible = false;
                    //---------

                    Label63.Visible = false;
                    Label64.Visible = false;
                    TextBox33.Visible = false;
                    //---------

                    Label73.Visible = false;
                    Label74.Visible = false;
                    TextBox39.Visible = false;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                } //yas
                else if ((amd.Length - 1) == 0)
                {

                    conte1.Visible = false;
                    conte2.Visible = false;
                    conte3.Visible = false;
                    conte4.Visible = false;
                    conte5.Visible = false;
                    conte6.Visible = false;
                    conte7.Visible = false;
                    conte8.Visible = false;
                    conte9.Visible = false;
                    conte10.Visible = false;

                    Label23.Visible = false;
                    Label24.Visible = false;
                    TextBox9.Visible = false;
                    //--------

                    Label33.Visible = false;
                    Label34.Visible = false;
                    TextBox15.Visible = false;
                    //--------


                    Label43.Visible = false;
                    Label44.Visible = false;
                    TextBox21.Visible = false;
                    //------


                    Label53.Visible = false;
                    Label54.Visible = false;
                    TextBox27.Visible = false;
                    //---------

                    Label63.Visible = false;
                    Label64.Visible = false;
                    TextBox33.Visible = false;
                    //---------

                    Label73.Visible = false;
                    Label74.Visible = false;
                    TextBox39.Visible = false;
                    //----------


                    Label83.Visible = false;
                    Label84.Visible = false;
                    TextBox45.Visible = false;
                    //--------


                    Label93.Visible = false;
                    Label94.Visible = false;
                    TextBox51.Visible = false;
                    //----------


                    Label103.Visible = false;
                    Label104.Visible = false;
                    TextBox57.Visible = false;
                    //-----------


                    Label113.Visible = false;
                    Label114.Visible = false;
                    TextBox63.Visible = false;
                } //yas
            }



        }

        protected void Button18_Click(object sender, EventArgs e)
        {
            ipc2.LoginyCrear inicio = new ipc2.LoginyCrear();
            Boolean Service;
            Boolean Service1;

            inicio.insertarcomentario(TextBox64.Text, Convert.ToInt32(Label113.Text), Convert.ToInt32(Session["idusuario"].ToString()), out Service, out Service1);
            if (Service == true)
            {
                Response.Redirect("inicio.aspx");
            }
            else
            {
                Label22.Text = "Error(601) - comentario";
            }
        }

        protected void Button18_Click1(object sender, EventArgs e)
        {
            Response.Redirect("denuncias.aspx");
        }
    }
    
}